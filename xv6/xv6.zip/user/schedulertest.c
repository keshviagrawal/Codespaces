// In user/schedulertest.c

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define NFORK 10
#define IO 5

int main() {
  int n, pid;
  int wtime, rtime;
  int total_wtime = 0, total_rtime = 0;

  for (n = 0; n < NFORK; n++) {
    pid = fork();
    if (pid < 0)
      break;
    if (pid == 0) { // Child process
      if (n < IO) {
        pause(200); // I/O-bound process using your pause() syscall
      } else {
        for (volatile int i = 0; i < 1000000000; i++) {} // CPU-bound process
      }
      exit(0);
    }
  }

  // Parent process waits for all children
  for (; n > 0; n--) {
    // Use waitx to get the wait time and run time of each child
    pid = waitx(0, &wtime, &rtime);
    printf("PID: %d, Wait Time: %d, Run Time: %d\n", pid, wtime, rtime);
    total_wtime += wtime;
    total_rtime += rtime;
  }

  printf("\n--- Test Summary ---\n");
  printf("Average Wait Time: %d\n", total_wtime / NFORK);
  printf("Average Run Time: %d\n", total_rtime / NFORK);

  exit(0);
}